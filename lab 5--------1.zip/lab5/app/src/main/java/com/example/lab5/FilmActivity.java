package com.example.lab5;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class FilmActivity extends AppCompatActivity {

    private final String[] filmler = {
            "Yüzüklerin Efendisi",
            "Yıldızlararası",
            "Başlangıç",
            "Matrix"
    };

    private final int[] afisler = {
            R.drawable.yuzuklerin_efendisi,
            R.drawable.yildizlararasi,
            R.drawable.baslangic,
            R.drawable.matrix
    };

    // Her filmin puanı ayrı tutulur
    private final float[] puanlar = new float[4];

    // Gönderilen puanlar (-1 = gönderilmedi)
    private final float[] gonderilen = {-1, -1, -1, -1};

    private ImageView ivAfis;
    private RatingBar rbPuan;
    private TextView tvPuan, tvOrtalama;
    private int seciliFilm = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_film);

        Spinner spFilm = findViewById(R.id.spFilm);
        ivAfis = findViewById(R.id.ivAfis);
        rbPuan = findViewById(R.id.rbPuan);
        tvPuan = findViewById(R.id.tvPuan);
        tvOrtalama = findViewById(R.id.tvOrtalama);
        Button btnGonder = findViewById(R.id.btnGonder);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, filmler);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spFilm.setAdapter(adapter);

        spFilm.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                seciliFilm = position;
                ivAfis.setImageResource(afisler[position]);
                rbPuan.setRating(puanlar[position]);
                puanYazisiniGuncelle(puanlar[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        rbPuan.setOnRatingBarChangeListener((bar, rating, fromUser) -> {
            puanlar[seciliFilm] = rating;
            puanYazisiniGuncelle(rating);
        });

        btnGonder.setOnClickListener(v -> {
            float puan = rbPuan.getRating();
            if (puan == 0) {
                Toast.makeText(this, "Lütfen önce puan verin!", Toast.LENGTH_SHORT).show();
                return;
            }
            gonderilen[seciliFilm] = puan;
            Toast.makeText(this, filmler[seciliFilm] + " puanlandı: " + puan,
                    Toast.LENGTH_SHORT).show();
            ortalamaGuncelle();
        });
    }

    private String yorum(float puan) {
        if (puan <= 1.5f) return "Kötü";
        if (puan <= 3f) return "Orta";
        if (puan <= 4.5f) return "İyi";
        return "Mükemmel";
    }

    private void puanYazisiniGuncelle(float puan) {
        tvPuan.setText(String.format(Locale.US, "%.1f / 5 · %s", puan, yorum(puan)));
    }

    private void ortalamaGuncelle() {
        float toplam = 0;
        int sayi = 0;
        for (float p : gonderilen) {
            if (p >= 0) {
                toplam += p;
                sayi++;
            }
        }
        if (sayi == 0) {
            tvOrtalama.setText("Ortalama: - (0 film)");
        } else {
            tvOrtalama.setText(String.format(Locale.US, "Ortalama: %.1f (%d film)",
                    toplam / sayi, sayi));
        }
    }
}