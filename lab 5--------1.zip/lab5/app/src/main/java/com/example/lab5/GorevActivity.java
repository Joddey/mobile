package com.example.lab5;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class GorevActivity extends AppCompatActivity {

    private CheckBox[] kutular;
    private ProgressBar pbGorev;
    private TextView tvDurum;
    private boolean sifirlaniyor = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gorev);

        kutular = new CheckBox[]{
                findViewById(R.id.cb1),
                findViewById(R.id.cb2),
                findViewById(R.id.cb3),
                findViewById(R.id.cb4),
                findViewById(R.id.cb5)
        };
        pbGorev = findViewById(R.id.pbGorev);
        tvDurum = findViewById(R.id.tvDurum);
        Button btnSifirla = findViewById(R.id.btnSifirla);

        // 5 CheckBox'a tek listener
        CompoundButton.OnCheckedChangeListener dinleyici = (buton, isaretli) -> {
            if (!sifirlaniyor) durumGuncelle(isaretli);
        };
        for (CheckBox cb : kutular) {
            cb.setOnCheckedChangeListener(dinleyici);
        }

        btnSifirla.setOnClickListener(v -> {
            sifirlaniyor = true;
            for (CheckBox cb : kutular) cb.setChecked(false);
            sifirlaniyor = false;
            durumGuncelle(false);
        });
    }

    private void durumGuncelle(boolean yeniIsaretlendi) {
        int sayi = 0;
        for (CheckBox cb : kutular) {
            if (cb.isChecked()) sayi++;
        }

        int yuzde = sayi * 100 / kutular.length;
        pbGorev.setProgress(sayi);
        tvDurum.setText(sayi + " / " + kutular.length + " görev · %" + yuzde);

        if (sayi == kutular.length && yeniIsaretlendi) {
            Toast.makeText(this, "Tebrikler!", Toast.LENGTH_SHORT).show();
        }
    }
}