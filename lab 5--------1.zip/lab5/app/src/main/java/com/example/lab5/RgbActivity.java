package com.example.lab5;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class RgbActivity extends AppCompatActivity {

    private SeekBar sbRed, sbGreen, sbBlue;
    private TextView tvRed, tvGreen, tvBlue, tvRgb;
    private View renkKutusu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rgb);

        sbRed = findViewById(R.id.sbRed);
        sbGreen = findViewById(R.id.sbGreen);
        sbBlue = findViewById(R.id.sbBlue);
        tvRed = findViewById(R.id.tvRed);
        tvGreen = findViewById(R.id.tvGreen);
        tvBlue = findViewById(R.id.tvBlue);
        tvRgb = findViewById(R.id.tvRgb);
        renkKutusu = findViewById(R.id.renkKutusu);

        SeekBar.OnSeekBarChangeListener dinleyici = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                renkGuncelle();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        };

        sbRed.setOnSeekBarChangeListener(dinleyici);
        sbGreen.setOnSeekBarChangeListener(dinleyici);
        sbBlue.setOnSeekBarChangeListener(dinleyici);

        renkGuncelle();
    }

    private void renkGuncelle() {
        int r = sbRed.getProgress();
        int g = sbGreen.getProgress();
        int b = sbBlue.getProgress();

        renkKutusu.setBackgroundColor(Color.rgb(r, g, b));

        tvRed.setText("Red: " + r);
        tvGreen.setText("Green: " + g);
        tvBlue.setText("Blue: " + b);
        tvRgb.setText("rgb(" + r + ", " + g + ", " + b + ")");
    }
}