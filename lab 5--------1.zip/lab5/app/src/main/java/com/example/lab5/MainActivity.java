package com.example.lab5;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnRgb = findViewById(R.id.btnRgb);
        Button btnFilm = findViewById(R.id.btnFilm);
        Button btnGorev = findViewById(R.id.btnGorev);

        btnRgb.setOnClickListener(v -> startActivity(new Intent(this, RgbActivity.class)));
        btnFilm.setOnClickListener(v -> startActivity(new Intent(this, FilmActivity.class)));
        btnGorev.setOnClickListener(v -> startActivity(new Intent(this, GorevActivity.class)));
    }
}